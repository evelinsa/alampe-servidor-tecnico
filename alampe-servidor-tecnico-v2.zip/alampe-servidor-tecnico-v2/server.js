import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const PORT = process.env.PORT || 3001;
const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY || '';
const GOOGLE_CSE_ID = process.env.GOOGLE_CSE_ID || '';
const SERPAPI_KEY = process.env.SERPAPI_KEY || '';

const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 1000 * 60 * 60 * 24 * 7); // 7 dias
const cacheAplicacao = new Map();
const cacheMercadoLivre = new Map();

const TRUSTED_DOMAINS = (process.env.TRUSTED_DOMAINS || [
  'nakata.com.br',
  'cofap.com.br',
  'mmcofap.com.br',
  'catalogo.mmcofap.com.br',
  'marelli.com.br',
  'schaeffler.com.br',
  'boschaftermarket.com',
  'dana.com',
  'mercadolivre.com.br',
  'autopecasonline24.com.br',
  'jocar.com.br',
  'hipervarejo.com.br',
  'pecaagora.com.br'
].join(',')).split(',').map(s => s.trim()).filter(Boolean);

const VEICULOS_CONHECIDOS = [
  'GOL','VOYAGE','SAVEIRO','PARATI','FOX','POLO','GOLF','UP','JETTA','PASSAT','SANTANA','KOMBI',
  'ONIX','PRISMA','CELTA','CORSA','CLASSIC','ASTRA','VECTRA','MERIVA','MONTANA','S10','CRUZE','COBALT','SPIN','TRACKER','ZAFIRA',
  'PALIO','UNO','SIENA','STRADA','IDEA','PUNTO','LINEA','BRAVO','ARGO','CRONOS','TORO','MOBI','DOBLO','FIORINO',
  'HB20','HB20S','TUCSON','IX35','CRETA','I30','AZERA','ELANTRA','SONATA','SANTA FE',
  'KA','FIESTA','FOCUS','ECOSPORT','RANGER','FUSION','COURIER','ESCORT','CORCEL',
  'CIVIC','CITY','FIT','HRV','CRV','ACCORD',
  'COROLLA','HILUX','ETIOS','YARIS','SW4','RAV4','CAMRY',
  'SANDERO','LOGAN','DUSTER','KWID','CLIO','MEGANE','SCENIC','CAPTUR',
  '208','207','206','307','308','2008','3008','PARTNER',
  'C3','C4','AIRCROSS','XSARA','PICASSO','BERLINGO',
  'RENEGADE','COMPASS','COMMANDER','CHEROKEE','WRANGLER',
  'TIGGO','QQ','CELER','FACE',
  'FRONTIER','MARCH','VERSA','SENTRA','KICKS','LIVINA',
  'PAJERO','L200','ASX','OUTLANDER',
  'AMAROK','T-CROSS','NIVUS','VIRTUS','TAOS'
];

const PECAS_LADO = /\b(FAROL|LANTERNA|RETROVISOR|PARALAMA|PARA-LAMA|PORTA|VIDRO|MAÇANETA|MOLDURA|SUPORTE|MILHA|PISCA|PONTEIRA)\b/i;
const PECAS_POSICAO = /\b(PARA-CHOQUE|PARACHOQUE|AMORTECEDOR|BANDEJA|DISCO|PASTILHA|MOLA|CUBO|ROLAMENTO|CAPO|CAPÔ|GRADE|RADIADOR|CONDENSADOR|VENTOINHA|PAINEL)\b/i;

function normalize(text = '') {
  return String(text)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s\/.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanSnippet(text = '') {
  return String(text)
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .replace(/[|•·]+/g, ' ')
    .trim();
}

function getCache(map, key) {
  const item = map.get(key);
  if (!item) return null;
  if (Date.now() - item.ts > CACHE_TTL_MS) {
    map.delete(key);
    return null;
  }
  return item.data;
}

function setCache(map, key, data) {
  map.set(key, { ts: Date.now(), data });
}

function getBrowserHeaders(extra = {}) {
  return {
    'Accept': 'application/json,text/plain,*/*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36',
    ...extra
  };
}

function getHost(link) {
  try { return new URL(link).hostname.replace(/^www\./, ''); } catch { return ''; }
}

function extractYears(text) {
  return [...String(text).matchAll(/(?:19|20)\d{2}(?:\s*[\/\-]\s*(?:19|20)\d{2})?/g)]
    .map(m => m[0].replace(/\s+/g, ''))
    .slice(0, 10);
}

function detectVeiculos(text) {
  const n = normalize(text).toUpperCase();
  return VEICULOS_CONHECIDOS.filter(v => new RegExp(`\\b${v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(n)).slice(0, 6);
}

function dinheiroParaNumero(value) {
  if (typeof value === 'number') return value;
  const raw = String(value || '').replace(/[^\d,.]/g, '').trim();
  if (!raw) return 0;
  if (raw.includes(',') && raw.includes('.')) return Number(raw.replace(/\./g, '').replace(',', '.'));
  if (raw.includes(',')) return Number(raw.replace(',', '.'));
  return Number(raw);
}

function slugifyMercadoLivre(q) {
  return normalize(q).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, '-').replace(/^-|-$/g, '');
}

function cleanDuckUrl(url) {
  try {
    const decoded = String(url || '').replace(/&amp;/g, '&');
    const u = new URL(decoded, 'https://duckduckgo.com');
    const uddg = u.searchParams.get('uddg');
    return uddg ? decodeURIComponent(uddg) : u.href;
  } catch {
    return url;
  }
}

async function withTimeout(promise, ms = 9000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), ms);
  try {
    if (typeof promise === 'function') return await promise(controller.signal);
    return await promise;
  } finally {
    clearTimeout(t);
  }
}

async function googleCseSearch(query) {
  if (!GOOGLE_API_KEY || !GOOGLE_CSE_ID) return [];
  const domains = TRUSTED_DOMAINS.slice(0, 7).map(d => `site:${d}`).join(' OR ');
  const q = `${query} aplicação compatibilidade catálogo autopeças ${domains ? `(${domains})` : ''}`;
  const url = new URL('https://www.googleapis.com/customsearch/v1');
  url.searchParams.set('key', GOOGLE_API_KEY);
  url.searchParams.set('cx', GOOGLE_CSE_ID);
  url.searchParams.set('q', q);
  url.searchParams.set('num', '10');
  const r = await withTimeout((signal) => fetch(url, { signal, headers: getBrowserHeaders({ 'Accept': 'application/json' }) }), 9000);
  if (!r.ok) throw new Error(`Google CSE HTTP ${r.status}`);
  const data = await r.json();
  return (data.items || []).map(it => ({
    title: it.title || '',
    snippet: it.snippet || '',
    link: it.link || '',
    fonte: getHost(it.link) || 'Google'
  }));
}

async function serpApiSearch(query) {
  if (!SERPAPI_KEY) return [];
  const q = `${query} aplicação compatibilidade catálogo autopeças`;
  const url = new URL('https://serpapi.com/search.json');
  url.searchParams.set('engine', 'google');
  url.searchParams.set('google_domain', 'google.com.br');
  url.searchParams.set('gl', 'br');
  url.searchParams.set('hl', 'pt-br');
  url.searchParams.set('q', q);
  url.searchParams.set('api_key', SERPAPI_KEY);
  const r = await withTimeout((signal) => fetch(url, { signal, headers: getBrowserHeaders() }), 9000);
  if (!r.ok) throw new Error(`SerpAPI HTTP ${r.status}`);
  const data = await r.json();
  return (data.organic_results || []).slice(0, 10).map(it => ({
    title: it.title || '',
    snippet: it.snippet || '',
    link: it.link || '',
    fonte: it.source || getHost(it.link) || 'Google'
  }));
}

async function duckDuckGoSearch(query) {
  const domains = TRUSTED_DOMAINS.filter(d => !d.includes('*')).slice(0, 10).map(d => `site:${d}`).join(' OR ');
  const q = `${query} aplicação compatibilidade catálogo autopeças ${domains ? `(${domains})` : ''}`;
  const url = new URL('https://html.duckduckgo.com/html/');
  url.searchParams.set('q', q);
  const r = await withTimeout((signal) => fetch(url, {
    signal,
    headers: getBrowserHeaders({ 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' })
  }), 9000);
  if (!r.ok) throw new Error(`DuckDuckGo HTTP ${r.status}`);
  const html = await r.text();
  const results = [];
  const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>|<div[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/div>)/gi;
  let m;
  while ((m = re.exec(html)) && results.length < 10) {
    const link = cleanDuckUrl(m[1]);
    results.push({
      title: cleanSnippet(m[2]),
      snippet: cleanSnippet(m[3] || m[4] || ''),
      link,
      fonte: getHost(link) || 'DuckDuckGo'
    });
  }
  return results;
}

async function wikipediaSearch(query) {
  const veiculos = detectVeiculos(query);
  if (!veiculos.length) return [];
  const termo = veiculos[0];
  const url = new URL('https://pt.wikipedia.org/w/api.php');
  url.searchParams.set('action', 'query');
  url.searchParams.set('list', 'search');
  url.searchParams.set('format', 'json');
  url.searchParams.set('origin', '*');
  url.searchParams.set('srsearch', `${termo} automóvel`);
  url.searchParams.set('srlimit', '3');
  const r = await withTimeout((signal) => fetch(url, { signal, headers: getBrowserHeaders() }), 7000);
  if (!r.ok) throw new Error(`Wikipedia HTTP ${r.status}`);
  const data = await r.json();
  return (data.query?.search || []).map(it => ({
    title: it.title || termo,
    snippet: cleanSnippet(it.snippet || ''),
    link: `https://pt.wikipedia.org/wiki/${encodeURIComponent(String(it.title || termo).replace(/ /g, '_'))}`,
    fonte: 'Wikipedia'
  }));
}

function buildApplication(item, query) {
  const title = cleanSnippet(item.title || '');
  const snippet = cleanSnippet(item.snippet || item.resumo || '');
  const sourceText = `${title}. ${snippet}`;
  let app = sourceText.toUpperCase();

  app = app
    .replace(/\b(COMPRAR|PREÇO|VALOR|FRETE|ENVIO|PROMOÇÃO|MERCADO LIVRE|AMAZON|SHOPEE|NOVO|USADO|ORIGINAL|PARALELO|OFERTA|ANÚNCIO)\b/g, ' ')
    .replace(/R\$\s*[0-9.,]+/g, ' ')
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const years = extractYears(sourceText);
  const veiculos = detectVeiculos(sourceText || query);
  const queryUpper = String(query || '').toUpperCase();

  if (!years.length && veiculos.length) {
    app = `${queryUpper} - COMPATIBILIDADE RELACIONADA A ${veiculos.join(', ')}`;
  } else if (!veiculos.length && !years.length) {
    app = `${queryUpper} - RESULTADO TÉCNICO ENCONTRADO EM ${item.fonte || 'FONTE EXTERNA'}`;
  }

  if (app.length > 190) app = app.slice(0, 190).replace(/\s+\S*$/, '');
  return app;
}

function buildHeuristicResults(query) {
  const q = String(query || '').trim().toUpperCase();
  const veiculos = detectVeiculos(q);
  const years = extractYears(q);
  const lado = PECAS_LADO.test(q) ? 'VERIFICAR LADO: DIREITO / ESQUERDO / PAR' : '';
  const pos = PECAS_POSICAO.test(q) ? 'VERIFICAR POSIÇÃO: DIANTEIRO / TRASEIRO / SUPERIOR / INFERIOR' : '';

  const detalhes = [
    veiculos.length ? `VEÍCULO IDENTIFICADO: ${veiculos.join(', ')}` : '',
    years.length ? `ANO INFORMADO: ${years.join(', ')}` : '',
    lado,
    pos,
    'CONFIRMAR PELO CÓDIGO DA PEÇA, ENCAIXE, MODELO, GERAÇÃO E FOTO ANTES DA VENDA'
  ].filter(Boolean).join(' • ');

  return [{
    aplicacao: `${q} - CONSULTA ORIENTATIVA INTERNA`,
    resumo: detalhes || 'Consulta orientativa gerada pelo servidor técnico. Confirme aplicação pelo veículo e pela peça antes da venda.',
    fonte: 'Alampe Técnico',
    link: '',
    confianca: 'orientativa'
  }];
}

function consolidateResults(raw, query) {
  const seen = new Set();
  const resultados = raw.map(item => {
    const aplicacao = buildApplication(item, query);
    return {
      aplicacao,
      resumo: cleanSnippet(`${item.title || ''}. ${item.snippet || ''}`),
      fonte: item.fonte || 'Fonte externa',
      link: item.link || '',
      confianca: item.fonte === 'Alampe Técnico' ? 'orientativa' : 'fonte_externa'
    };
  }).filter(item => {
    const key = normalize(item.aplicacao);
    if (!key || key.length < 8 || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 8);

  if (!resultados.length) return buildHeuristicResults(query);
  return resultados;
}

async function buscarAplicacaoIntegrada(q) {
  const cacheKey = normalize(q);
  const cached = getCache(cacheAplicacao, cacheKey);
  if (cached) return { ...cached, cache: true };

  const avisos = [];
  const fontesUsadas = [];
  let raw = [];

  const etapas = [
    ['google_cse', googleCseSearch],
    ['serpapi', serpApiSearch],
    ['duckduckgo', duckDuckGoSearch],
    ['wikipedia', wikipediaSearch]
  ];

  for (const [nome, fn] of etapas) {
    try {
      const r = await fn(q);
      if (r?.length) {
        raw.push(...r);
        fontesUsadas.push(nome);
      }
      if (raw.length >= 8) break;
    } catch (e) {
      avisos.push(`${nome}: ${e.message}`);
      console.warn(`[${nome}]`, e.message);
    }
  }

  const resultados = consolidateResults(raw, q);
  const metodo = fontesUsadas.length ? fontesUsadas.join('+') : 'fallback_orientativo';
  const data = {
    ok: true,
    consulta: q,
    metodo,
    resultados,
    avisos: avisos.length ? avisos : undefined
  };
  setCache(cacheAplicacao, cacheKey, data);
  return data;
}

async function mercadoLivreApiSearch(q, limit) {
  const url = new URL('https://api.mercadolibre.com/sites/MLB/search');
  url.searchParams.set('q', q);
  url.searchParams.set('limit', String(limit));
  const r = await withTimeout((signal) => fetch(url, {
    signal,
    headers: getBrowserHeaders({ 'Origin': 'https://www.mercadolivre.com.br', 'Referer': 'https://www.mercadolivre.com.br/' })
  }), 9000);
  if (!r.ok) throw new Error(`Mercado Livre API HTTP ${r.status}`);
  const data = await r.json();
  return (data.results || []).map(i => ({
    title: i.title || 'ANÚNCIO',
    price: Number(i.price || 0),
    condition: i.condition || '',
    permalink: i.permalink || '',
    fonte: 'Mercado Livre',
    metodo: 'api'
  })).filter(i => Number.isFinite(i.price) && i.price > 0);
}

async function mercadoLivreHtmlSearch(q, limit) {
  const slug = slugifyMercadoLivre(q);
  const url = `https://lista.mercadolivre.com.br/${encodeURIComponent(slug)}`;
  const r = await withTimeout((signal) => fetch(url, {
    signal,
    headers: getBrowserHeaders({ 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Referer': 'https://www.mercadolivre.com.br/' })
  }), 9000);
  if (!r.ok) throw new Error(`Mercado Livre HTML HTTP ${r.status}`);
  const html = await r.text();
  const itens = [];
  const blocks = html.split('ui-search-layout__item').slice(1, limit + 1);
  for (const block of blocks) {
    const titleMatch = block.match(/(?:ui-search-item__title|poly-component__title)[^>]*>([\s\S]*?)<\/[^>]+>/i) || block.match(/title="([^"]{8,180})"/i);
    const fracMatch = block.match(/andes-money-amount__fraction[^>]*>([\d\.]+)<\/span>/i);
    const centsMatch = block.match(/andes-money-amount__cents[^>]*>(\d{2})<\/span>/i);
    const linkMatch = block.match(/href="(https:\/\/produto\.mercadolivre\.com\.br[^"]+)"/i) || block.match(/href="(https:\/\/www\.mercadolivre\.com\.br[^"]+)"/i);
    if (!titleMatch || !fracMatch) continue;
    const title = cleanSnippet(titleMatch[1] || titleMatch[0]);
    const price = dinheiroParaNumero(`${fracMatch[1]},${centsMatch ? centsMatch[1] : '00'}`);
    if (title && price > 0) itens.push({ title, price, condition: '', permalink: linkMatch ? linkMatch[1].replace(/&amp;/g, '&') : url, fonte: 'Mercado Livre', metodo: 'html' });
  }
  return itens;
}

function uniqByTitlePrice(items) {
  const seen = new Set();
  return items.filter(i => {
    const key = `${normalize(i.title).slice(0, 80)}|${Math.round(i.price)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

app.get('/', (req, res) => {
  res.json({
    ok: true,
    nome: 'Servidor Técnico Alampe V2',
    versao: '20260625-busca-integrada-v2',
    rotas: ['/api/health', '/api/aplicacao?q=farol%20classic%202005', '/api/mercadolivre?q=farol%20classic%202005']
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    nome: 'Servidor Técnico Alampe V2',
    versao: '20260625-busca-integrada-v2',
    googleCse: Boolean(GOOGLE_API_KEY && GOOGLE_CSE_ID),
    serpApi: Boolean(SERPAPI_KEY),
    fallbackDuckDuckGo: true,
    fallbackWikipedia: true,
    fallbackOrientativo: true,
    cacheAplicacao: cacheAplicacao.size,
    cacheMercadoLivre: cacheMercadoLivre.size
  });
});

app.get('/api/aplicacao', async (req, res) => {
  try {
    const q = String(req.query.q || '').trim();
    if (!q) return res.status(400).json({ ok: false, erro: 'Informe a peça para pesquisar.' });
    const data = await buscarAplicacaoIntegrada(q);
    return res.json(data);
  } catch (e) {
    console.error(e);
    // Nunca derruba a busca técnica por instabilidade externa.
    return res.json({
      ok: true,
      consulta: String(req.query.q || '').trim(),
      metodo: 'fallback_orientativo_erro',
      resultados: buildHeuristicResults(String(req.query.q || '').trim()),
      avisos: [e.message || 'Erro externo contornado por fallback.']
    });
  }
});

app.get('/api/mercadolivre', async (req, res) => {
  const erros = [];
  try {
    const q = String(req.query.q || '').trim();
    const limit = Math.min(Number(req.query.limit || 50), 50);
    if (!q) return res.status(400).json({ ok: false, erro: 'Informe a peça.' });

    const cacheKey = `${normalize(q)}|${limit}`;
    const cached = getCache(cacheMercadoLivre, cacheKey);
    if (cached) return res.json({ ...cached, cache: true });

    let itens = [];
    try { itens = await mercadoLivreApiSearch(q, limit); } catch (e) { erros.push(e.message); console.warn(e.message); }
    if (!itens.length) {
      try { itens = await mercadoLivreHtmlSearch(q, limit); } catch (e) { erros.push(e.message); console.warn(e.message); }
    }

    itens = uniqByTitlePrice(itens).slice(0, limit);

    const data = itens.length
      ? { ok: true, consulta: q, itens, avisos: erros.length ? erros : undefined }
      : { ok: true, consulta: q, itens: [], avisos: erros.length ? erros : ['Consulta de preço indisponível no momento. Use o modo manual.'] };

    setCache(cacheMercadoLivre, cacheKey, data);
    return res.json(data);
  } catch (e) {
    console.error(e);
    return res.json({ ok: true, consulta: String(req.query.q || '').trim(), itens: [], avisos: [e.message || 'Erro contornado. Use o modo manual.'] });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor Técnico Alampe V2 rodando na porta ${PORT}`);
});
